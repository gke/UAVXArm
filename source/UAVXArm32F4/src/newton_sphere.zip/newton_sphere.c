/*
 # copyright 2012 by Rolfe Schmidt
 modifications for UAVXArm (C) 2015 Prof G.K. Egan

 This file is part of muCSense.

 muCSense is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 muCSense is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with muCSense.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "UAVX.h"

#if defined(USE_NEWTON_SPHERE)

void clearObservationMatrices();
void guessParameters();
void clearGNMatrices(real32 JtJ[][6], real32 JtR[]);
void computeGNMatrices(real32 JtJ[][6], real32 JtR[]);
void findDelta(real32 JtJ[][6], real32 JtR[]);
int16 upperTriangularIndex(int16 i, int16 j);

// const Sensor* _pSensor;

//observation summary structures
real32 _mu[3]; //sum of all observations in each dimension
real32 _mu2[3]; //sum of squares of all observations in each dimension
real32 _ipXX[6]; //Symmetric matrix of inner products of observations with themselves
real32 _ipX2X[3][3]; //matrix of inner products of squares of observations with the observations
real32 _ipX2X2[6]; //Symmetric matrix of inner products of squares of observations with themselves
int16 _N; //The number of observations

int16 _obsMin[3]; // Keep track of min and max observation in each dimension to guess parameters
int16 _obsMax[3]; // Keep track of min and max observation in each dimension to guess parameters


//Final calibration parameters
real32 _beta[6];
//size upperTriangularIndex(size i, size j);


void newtonUpdate(int16 x, int16 y, int16 z) {
	int16 i, j, idx;
	int16 obs[3];

	obs[0] = x;
	obs[1] = y;
	obs[2] = z;

	//increment sample count
	++_N;

	int32 squareObs[3];
	for (i = 0; i < 3; ++i) {
		real32 curObs = obs[i]; //implicitly convert to bigger int
		squareObs[i] = curObs * curObs; //square of 16-bit int will fit in 32-bit int
	}

	for (i = 0; i < 3; ++i) {
		//Keep track of min and max in each dimension
		_obsMin[i] = (obs[i] < _obsMin[i]) ? obs[i] : _obsMin[i];
		_obsMax[i] = (obs[i] > _obsMax[i]) ? obs[i] : _obsMax[i];

		//accumulate sum and sum of squares in each dimension
		_mu[i] += obs[i];
		_mu2[i] += squareObs[i];

		//accumulate inner products of the vector of observations and the vector of squared observations.
		for (j = 0; j < 3; ++j) {
			_ipX2X[i][j] += squareObs[i] * (int32) (obs[j]);
			if (i <= j) {
				idx = upperTriangularIndex(i, j);
				_ipXX[idx] += (int32) (obs[i]) * (int32) (obs[j]);
				_ipX2X2[idx] += squareObs[i] * (real32) (squareObs[j]);
			}
		}
	}

} // newtonUpdate

void clearObservationMatrices(void) {
	int16 i, j;

	_N = 0;
	memset(_mu, 0, 3 * sizeof(real32));
	memset(_mu2, 0, 3 * sizeof(real32));
	memset(_ipXX, 0, 6 * sizeof(real32));
	memset(_ipX2X2, 0, 6 * sizeof(real32));

	memset(_obsMin, 0, 3 * sizeof(int16));
	memset(_obsMax, 0, 3 * sizeof(int16));

	for (i = 0; i < 3; ++i) {
		_obsMin[i] = 0x7fff; //INT16_MAX;
		_obsMax[i] = (-0x7fff - 1); //INT16_MIN;
		for (j = 0; j < 3; ++j)
			_ipX2X[i][j] = 0.0;
	}
} // clearObservationMatrices

void clearGNMatrices(real32 JtJ[][6], real32 JtR[]) {
	int16 j, k;
	for (j = 0; j < 6; ++j) {
		JtR[j] = 0.0;
		for (k = 0; k < 6; ++k)
			JtJ[j][k] = 0.0;
	}
} // newtonClearGNMatrices

void newtonTransform(const int16* rawInput, real32* output) {
	int16 i;

	for (i = 0; i < 3; ++i)
		output[i] = ((real32) (rawInput[i]) - _beta[i]) / _beta[3 + i];

} // newtonTransform

void computeGNMatrices(real32 JtJ[][6], real32 JtR[]) {
	int16 i, j;

	real32 beta2[6]; //precompute the squares of the model parameters
	for (i = 0; i < 6; ++i)
		beta2[i] = pow(_beta[i], 2);

	//compute the inner product of the vector of residuals with the constant 1 vector, the vector of
	// observations, and the vector of squared observations.
	real32 r = _N; //sum of residuals
	real32 rx[3]; //Inner product of vector of residuals with each observation vector
	real32 rx2[3]; //Inner product of vector of residuals with each square observation vector


	//now correct the r statistics
	for (i = 0; i < 3; ++i) {
		r -= (beta2[i] * _N + _mu2[i] - 2 * _beta[i] * _mu[i]) / beta2[3 + i];
		rx[i] = _mu[i];
		rx2[i] = _mu2[i];
		for (j = 0; j < 3; ++j) {
			rx[i] -= (beta2[j] * _mu[i] + _ipX2X[j][i] - 2
					* _ipXX[upperTriangularIndex(i, j)] * _beta[j]) / beta2[3
					+ j];
			rx2[i] -= (beta2[j] * _mu2[i] + _ipX2X2[upperTriangularIndex(i, j)]
					- 2 * _ipX2X[i][j] * _beta[j]) / beta2[3 + j];
		}
	}

	for (i = 0; i < 3; ++i) {
		//Compute product of Jacobian matrix with the residual vector
		JtR[i] = 2 * (rx[i] - _beta[i] * r) / beta2[3 + i];
		JtR[3 + i] = 2 * (rx2[i] - 2 * _beta[i] * rx[i] + beta2[i] * r)
				/ (beta2[3 + i] * _beta[3 + i]);

		//Now compute the product of the transpose of the jacobian with itself
		//Start with the diagonal blocks
		for (j = i; j < 3; ++j) {
			JtJ[i][j] = JtJ[j][i] = 4 * (_ipXX[upperTriangularIndex(i, j)]
					- _beta[i] * _mu[j] - _beta[j] * _mu[i] + _beta[i]
					* _beta[j] * _N) / (beta2[3 + i] * beta2[3 + j]);
			JtJ[3 + i][3 + j] = JtJ[3 + j][3 + i] = 4
					* (_ipX2X2[upperTriangularIndex(i, j)] - 2 * _beta[j]
							* _ipX2X[i][j] + beta2[j] * _mu2[i] - 2 * _beta[i]
							* _ipX2X[j][i] + 4 * _beta[i] * _beta[j]
							* _ipXX[upperTriangularIndex(i, j)] - 2 * _beta[i]
							* beta2[j] * _mu[i] + beta2[i] * _mu2[j] - 2
							* beta2[i] * _beta[j] * _mu[j] + beta2[i]
							* beta2[j] * _N) / pow(_beta[3 + i] * _beta[3 + j],
					3);
		}
		//then get the off diagonal blocks
		for (j = 0; j < 3; ++j)
			JtJ[i][3 + j] = JtJ[3 + j][i] = 4 * (_ipX2X[j][i] - 2 * _beta[j]
					* _ipXX[upperTriangularIndex(i, j)] + beta2[j] * _mu[i]
					- _beta[i] * _mu2[j] + 2 * _beta[i] * _beta[j] * _mu[j]
					- _beta[i] * beta2[j] * _N) / (beta2[3 + i] * beta2[3 + j]
					* _beta[3 + j]);
	}
} // newtonComputeGNMatrices

void findDelta(real32 JtJ[][6], real32 JtR[]) {
	//Solve 6-d matrix equation JtJS*x = JtR
	//first put in upper triangular form
	//Serial.println("find delta");
	int i, j, k;
	real64 lambda;

	//make upper triangular
	for (i = 0; i < 6; ++i) {
		//eliminate all nonzero entries below JS[i][i]

		if (JtJ[i][i] == 0.0) {
			//Serial.print(" is zero!\n");
		}

		for (j = i + 1; j < 6; ++j) {
			lambda = JtJ[j][i] / JtJ[i][i];
			if (lambda != 0.0) {
				JtR[j] -= lambda * JtR[i];
				for (k = i; k < 6; ++k)
					JtJ[j][k] -= lambda * JtJ[i][k];
			}
		}
	}

	//back-substitute
	for (i = 5; i >= 0; --i) {
		JtR[i] /= JtJ[i][i];
		JtJ[i][i] = 1.0;
		for (j = 0; j < i; ++j) {
			lambda = JtJ[j][i];
			JtR[j] -= lambda * JtR[i];
			JtJ[j][i] = 0.0;
		}
	}

} // findDelta

void newtonCalibrate(void) {
	//Serial.println("calibrate");
	int16 i;
	guessParameters();
	real32 JtJ[6][6];
	real32 JtR[6];
	clearGNMatrices(JtJ, JtR);
	real32 eps = 0.000000001f;
	int num_iterations = 20;
	real32 change = 100.0f;

	while (--num_iterations >= 0 && change > eps) {

		computeGNMatrices(JtJ, JtR);
		findDelta(JtJ, JtR);

		change = JtR[0] * JtR[0] + JtR[1] * JtR[1] + JtR[2] * JtR[2] + JtR[3]
				* JtR[3] * (_beta[3] * _beta[3]) + JtR[4] * JtR[4] * (_beta[4]
				* _beta[4]) + JtR[5] * JtR[5] * (_beta[5] * _beta[5]);

		if (!isnan(change)) {
			for (i = 0; i < 6; ++i) {
				_beta[i] -= JtR[i];
				if (i >= 3)
					_beta[i] = fabs(_beta[i]);
			}
		}

		clearGNMatrices(JtJ, JtR);

	}

} // newtonCalibrate

int16 upperTriangularIndex(int16 i, int16 j) {
	int16 temp;

	if (i > j) {
		temp = i;
		i = j;
		j = temp;
	}

	return (j * (j + 1)) / 2 + i;
} // upperTriangularIndex

void guessParameters(void) {
	int16 i;

	for (i = 0; i < 3; ++i) {
		_beta[i] = ((real64) (_obsMax[i] + _obsMin[i])) * 0.5f;
		_beta[3 + i] = ((real64) (_obsMax[i] - _obsMin[i])) * 0.5f;
	}
} // newtonGuessParameters

#endif
